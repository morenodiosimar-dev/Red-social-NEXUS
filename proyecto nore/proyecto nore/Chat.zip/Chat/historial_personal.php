<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="http://localhost:3000/socket.io/socket.io.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
<link rel="stylesheet" href="historial.css">

</head>
<body>
    <div class="bloque">
        <h2 class="titulo-historial">Mis Chats</h2>
        
        <div id="status-debug" class="text-xs text-blue-500 mb-2">Iniciando sistema...</div>
        
        <div id="lista-historial" class="lista-h">
            <p class="text-gray-500 italic">Buscando conversaciones previas...</p>
        </div>
        <ion-icon onclick="window.history.back()" name="chevron-back-outline" class="devolver cursor-pointer" id="btn-devolver"></ion-icon>
    </div>

    <script>
        const debug = document.getElementById("status-debug");
        const contenedor = document.getElementById("lista-historial");

        // 1. Intentar conectar con Node.js
        const socket = io("http://localhost:3000");

        socket.on("connect", () => {
            debug.innerText = "✅ Conectado al servidor de Chat";
            
            // 2. Una vez conectado el socket, pedimos el usuario a PHP
            fetch("devuelve.php")
                .then(res => res.json())
                .then(data => {
                    if (data.success && data.usuario && data.id_usuario) {
                        debug.innerText = "Perfil de: " + data.usuario;
                        // 3. Pedimos el historial a Node.js usando ID
                        socket.emit("obtener_historial_contactos", { id_usuario: data.id_usuario });
                    } else {
                        debug.innerText = "❌ Error: No hay sesión activa en PHP";
                        contenedor.innerHTML = "Por favor, inicia sesión.";
                    }
                })
                .catch(err => {
                    debug.innerText = "❌ Error al conectar con devuelve.php";
                });
        });

        socket.on("connect_error", () => {
            debug.innerText = "❌ Error: El servidor Node.js (puerto 3000) no responde";
        });

        // 4. Recibir los datos de la base de datos
        socket.on("enviar_historial_contactos", (contactos) => {
            contenedor.innerHTML = "";
            if (contactos.length === 0) {
                contenedor.innerHTML = "<p class='text-gray-400'>No tienes chats guardados aún.</p>";
                return;
            }

            // contactos ahora es un array de objetos { id, nombre_completo, foto_perfil } o array de strings (compatibilidad)
            contactos.forEach(contacto => {
                const contactoData = typeof contacto === 'object' ? contacto : { id: contacto, nombre_completo: contacto, foto_perfil: 'default.png' };
                const nombreCompleto = contactoData.nombre_completo || contactoData.id || contacto;
                const idContacto = contactoData.id || contacto;
                const fotoPerfil = contactoData.foto_perfil || 'default.png';
                
                const div = document.createElement("div");
                div.className = "p-3 border rounded hover:bg-blue-50 cursor-pointer transition flex justify-between items-center";
                div.innerHTML = `
                    <div class="flex items-center space-x-3">
                        <img src="http://localhost/Chat/img/${fotoPerfil}" alt="Avatar" class="w-12 h-12 rounded-full object-cover border-2 border-gray-200" 
                             onerror="this.src='http://localhost/Chat/img/default.png'">
                        <div>
                            <div class="font-semibold text-gray-800">${nombreCompleto}</div>
                            <div class="text-xs text-gray-400">Conversación guardada</div>
                        </div>
                    </div>
                    <span class="text-blue-500">➔</span>
                `;
                div.onclick = () => {
                    // Pasar el ID del contacto en la URL (el script principal puede buscar por ID o nombre)
                    window.location.href = "http://localhost:3000?contacto=" + encodeURIComponent(idContacto);
                };
                contenedor.appendChild(div);
            });
        });
    </script>
</body>
</html>